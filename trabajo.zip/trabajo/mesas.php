<html>

<head>
    <title>Mesas</title>
    <meta charset="utf-8">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="crud.css">
</head>

<body>
    <?php
    include("conexion.php");
    $con = conectar();
    $sql = "SELECT * FROM tbl_mesas";
    $query = mysqli_query($con, $sql);
    ?>

    <div class="row no-gutters">
        <div class="col-md-6 no-gutters">
            <div class="leftside">
                <p align="left"><a href="menu_tp.html">Volver</a></p>
                <br>
                <h2 align="center"> Carga de mesas de examen </h2>
                <br> <br> <br>
                <center>
                    <table class="add">
                        <form action="insertar_mesa.php" method="POST">
                            <tr>
                                <td>Materia</td>
                                <td><input type="text" name="nombre"></td>
                            </tr>
                            <tr>
                                <td>Profesor</td>
                                <td><input type="text" name="prof"> </td>
                            </tr>
                            <tr>
                                <td>Profesor suplente</td>
                                <td><input type="text" name="suplente"></td>
                            </tr>
                            <tr>
                                <td>Profesor vocal suplente</td>
                                <td><input type="text" name="vocal"></td>
                            </tr>
                            <tr>
                                <td>Fecha de mesa</td>
                                <td><input type="date" name="fecha"></td>
                            </tr>
                            <td></td>
                            <td>
                                <center><input type="submit" value="Enviar"></center>
                            </td>
                            </tr>
                        </form>
                    </table>
                </center>
            </div>
        </div>
        <div class="col-md-6 no-gutters">
            <div class="rightside">
                <br>
                <br> <br>
                <h2 align="center">Listado de mesas</h2>
                <br>
                <center>
                    <table class="list">
                        <thead>
                            <tr>
                                <th>Materia</th>
                                <th>Profesor</th>
                                <th>Suplente</th>
                                <th>Vocal</th>
                                <th>Fecha</th>
                                <th></th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            while ($row = mysqli_fetch_array($query)) {
                                echo "<tr>";
                                echo "<td>$row[1]</td>";
                                echo "<td>$row[2]</td>";
                                echo "<td>$row[3]</td>";
                                echo "<td>$row[4]</td>";
                                echo "<td>$row[5]</td>";
                                echo "<td>
			                <form method='post' action='update_mesa.php'>
			                <input type='hidden' name='id' value='$row[0]'>
			                <input type='submit' value='EDITAR'>
			                </form>
			                </td>";
                                echo "<td>
			                <form method='post' action='delete_mesa.php'>
			                <input type='hidden' name='id' value='$row[0]'>
			                <input type='submit' value='ELIMINAR'>
			                </form>
			                </td>";
                                echo "</tr>";
                            }
                            mysqli_free_result($query);
                            mysqli_close($con);
                            ?>
                        </tbody>
                    </table>
                </center>
            </div>
        </div>
    </div>
</body>

</html>