<html>

<head>
    <title>Buscando mesa de examen</title>
    <meta charset="utf-8">
    <link rel="stylesheet" type="text/css" href="crud.css">

</head>

<body>
    <?php
    include("conexion.php");
    $con = conectar();

    $form_mat = $_POST["materia"];
    $consulta = "SELECT * FROM tbl_inscripciones WHERE mesa='$form_mat'";
    $resultado = mysqli_query($con, $consulta);
    $sql = "SELECT * FROM tbl_mesas WHERE id='$form_mat'";
    $query = mysqli_query($con, $sql);
    $mesa = mysqli_fetch_row($query);

    ?>
    <a href="alumno_mesa.php">Volver</a>
    <br> <br>
    <table border="1" width="90%">
        <p><b>La mesa seleccionada tiene a los siguientes alumnos inscriptos:</b></p>
        <tr>
            <th>Materia</th>
            <th>Fecha</th>
            <th>Asistencia</th>
            <th>Nota</th>
            <th>Apellido</th>
            <th>Nombre</th>
        </tr>
        <?php

        while ($inscripcion = mysqli_fetch_row($resultado)) {
            echo "<tr>";
            $alumno = "SELECT * FROM tbl_alumno WHERE id='$inscripcion[1]'";
            $result = mysqli_query($con, $alumno);
            $row = mysqli_fetch_row($result);
            echo "<td>$mesa[1]</td>";
            echo "<td>$mesa[5]</td>";
            echo "<td>$inscripcion[5]</td>";
            echo "<td>$inscripcion[6]</td>";
            echo "<td>$row[2]</td>";
            echo "<td>$row[1]</td>";
            echo "</tr>";
        }
        mysqli_close($con);

        ?>

</body>

</html>