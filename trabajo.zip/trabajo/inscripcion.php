 <html>

 <head>
     <title>Inscripciones</title>
     <meta charset="utf-8">
     <link rel="stylesheet" type="text/css" href="crud.css">
 </head>

 <body>
     <?php
        require("conexion.php");
        $con = conectar();
        $consulta = "SELECT * FROM tbl_alumno";
        $query_alum = mysqli_query($con, $consulta);
        date_default_timezone_set("America/Argentina/San_Juan");
        $hoy = date("o,m,d");
        $sql_mesa = "SELECT * FROM tbl_mesas WHERE fecha>='$hoy'";
        $query_mesa = mysqli_query($con, $sql_mesa);
        ?>
     <center>
         <p align="left"><a href="menu_tp.html">Volver</a></p>
         <br> <br>
         <br>
         <form method="POST" action="insertar_inscripcion.php">
             <center>
                 <table class="table">
                     <tr>
                         <th>Seleccione alumno</th>
                         <td><select name="alumno" required>
                                 <option value="0"></option>
                                 <?php while ($row = mysqli_fetch_array($query_alum)) {
                                        echo '<option value="', $row[0], '">', $row[2], ', ', $row[1], '</option>';
                                    }  ?>
                             </select></td>
                     </tr>
                     <tr>
                         <th>Seleccione mesa</th>
                         <td><select name="mesa" required>
                                 <option value="0"></option>
                                 <?php while ($row_mesa = mysqli_fetch_row($query_mesa)) {
                                        echo '<option value="', $row_mesa[0], '">', $row_mesa[1], ' </option>';
                                    } ?>
                             </select></td>
                     </tr>
                     <tr>
                         <th>Condicion</th>
                         <td><input type="radio" name="radio" value="Regular">Regular<input type="radio" name="radio" value="Libre">Libre</td>
                     </tr>
                     <tr>
                         <td></td>
                         <td><input type="submit" value="Enviar"></td>
                     </tr>

                 </table>
             </center>

         </form>

 </body>

 </html>