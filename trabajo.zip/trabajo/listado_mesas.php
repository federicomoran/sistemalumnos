<html>

<head>
    <title>Listado mesas</title>
    <link rel="stylesheet" type="text/css" href="tablas.css">
</head>

</html>

<body>
    <a href="operador.php">Volver</a>
    <?php
    include('conexion.php');
    $con = conectar();

    $sql = "SELECT * FROM tbl_mesas";
    $query = mysqli_query($con, $sql);

    ?>
    <div id="operador">
        <center>
            <table class="mesas">
                <thead>
                    <tr>
                        <th>Materia</th>
                        <th>Profesor</th>
                        <th>Suplente</th>
                        <th>Prof vocal</th>
                        <th>Fecha</th>
                    </tr>
                </thead>

                <?php
                while ($row = mysqli_fetch_row($query)) {
                    echo "<tr>";
                    echo "<td>$row[1]</td>";
                    echo "<td>$row[2]</td>";
                    echo "<td>$row[3]</td>";
                    echo "<td>$row[4]</td>";
                    echo "<td>$row[5]</td>";
                    echo "</tr>";
                }

                ?>
            </table>
        </center>
        <br> <br>
        <center><a href="inscripcion_op.php">Ir a generar una inscripcion</a></center>
    </div>
</body>