<?php
include("conexion.php");
$con = conectar();

$nombre = $_POST['nombre'];
$profesor = $_POST['prof'];
$suplente = $_POST['suplente'];
$vocal = $_POST['vocal'];
$date = $_POST['fecha'];
$consulta = "SELECT * FROM tbl_mesas";
$resultado = mysqli_query($con, $consulta);
while ($row = mysqli_fetch_row($resultado)) {
    if (($date == $row[5]) && ($nombre == $row[1])) {
        echo "<script>alert('Ya esta seleccionada la mesa de examen para esa fecha');
        window.location='mesas.php';
        </script>";
        exit();
    }
}

$sql = "INSERT INTO tbl_mesas (materia, profesor, suplente, vocal, fecha) VALUES ('$nombre', '$profesor', '$suplente', '$vocal', '$date')";
$query = mysqli_query($con, $sql);
echo "<script>alert('Su mesa fue creada con exito');
window.location='mesas.php';
</script>";
mysqli_close($con);
