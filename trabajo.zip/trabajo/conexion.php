<?php
function conectar()
{
    $server = "localhost";
    $us = "federico moran";
    $pass = "23100";
    $db = "trabajo";

    $con = mysqli_connect($server, $us, $pass, $db);

    mysqli_select_db($con, $db);

    return $con;
}
