<?php
include("conexion.php");
$con = conectar();

$form_id = $_POST["id"];
$form_no = $_POST["nombre"];
$form_ap = $_POST["apellido"];
$form_dni = $_POST["dni"];

$sql = "UPDATE tbl_alumno SET nombre='$form_no', apellido='$form_ap', dni='$form_dni' WHERE id='$form_id'";
if (!mysqli_query($con, $sql)) {
    echo "<p>$sql</p>";
    exit();
}
mysqli_close($con);
echo "<script>
alert('Se actualizo el alumno');
window.location='alumno.php';
</script>";
