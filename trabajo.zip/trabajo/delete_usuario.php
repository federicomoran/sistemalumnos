<?php
include("conexion.php");
$con = conectar();

$form_id = $_POST["id"];
$sql = "DELETE FROM tbl_usuario WHERE id='$form_id'";
if (!mysqli_query($con, $sql)) {
    echo "<p>$sql</p>";
    exit();
}
echo "<script>
    alert('El usuario fue eliminado');
    window.location='usuarios.php';
</script>";
mysqli_close($con);
