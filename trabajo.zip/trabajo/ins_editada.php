<?php
include("conexion.php");
$con = conectar();

$form_id = $_POST["id"];
$form_as = $_POST["asistencia"];
$form_no = $_POST["nota"];

$sql = "UPDATE tbl_inscripciones SET asistencia='$form_as', nota='$form_no' WHERE id='$form_id'";
if (!mysqli_query($con, $sql)) {
    echo "<p>$sql</p>";
    exit();
}
mysqli_close($con);
echo "<script>
alert('Se guardo la inscripcion con éxito');
window.location='editar_ins.php';
</script>";
