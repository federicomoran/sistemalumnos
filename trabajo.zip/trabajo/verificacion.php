<!DOCTYPE html>
<html>

<head>
    <title>Verificando</title>
    <meta charset="utf-8">
</head>

<body>
    <?php
    include('conexion.php');
    $con = conectar();


    $form_us = $_POST['usuario'];
    $form_co = $_POST['password'];
    $consulta = "SELECT * FROM tbl_usuario WHERE usuario='$form_us'";
    if (!$resultado = mysqli_query($con, $consulta)) {
        exit();
    }
    $row = mysqli_fetch_row($resultado);
    if ($form_co == $row[2]) {
        if ($row[4] == "Administrador") {
            echo "<script>
				alert('Bienvenido a Menu Instituto ');
				window.location='menu_tp.html';
				</script>";
        } else {
            echo "<script>
				alert('Bienvenido a Menu de operador');
				window.location='operador.php';
				</script>";
        }
    } else {
        echo "<script>
        alert('Su contraseña es incorrecta');
        window.location='acceso_us.html';
        </script>";
    }
    $var = $row[3];

    mysqli_close($con);
    ?>
</body>

</html>