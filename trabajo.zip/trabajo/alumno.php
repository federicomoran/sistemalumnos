<html>

<head>
    <title>Alumnos</title>
    <meta charset="utf-8">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="crud.css">
</head>

<body>
    <?php
    include("conexion.php");
    $con = conectar();
    $sql = "SELECT * FROM tbl_alumno";
    $query = mysqli_query($con, $sql);
    ?>

    <div class="row no-gutters">
        <div class="col-md-6 no-gutters">
            <div class="leftside">
                <p align="left"><a href="menu_tp.html">Volver</a></p>
                <br>
                <h2 align="center"> Ingrese alumnos </h2>
                <br>
                <center>
                    <table class="inserte">
                        <form action="insertar_alumno.php" method="POST">
                            <tr>
                                <td><br><input type="text" name="nombre" placeholder="Ingrese el nombre"></td>
                            </tr>
                            <tr>
                                <td><br><input type="text" name="apellido" placeholder="Ingrese el apellido" </td>
                            </tr>
                            <tr>
                                <td><br><input type="text" name="dni" placeholder="Ingrese el DNI"></td>
                            </tr>
                            <tr>
                                <td>
                                    <br>
                                    <center><input type="submit" value="Enviar"></center>
                                </td>
                            </tr>
                        </form>
                    </table>
                </center>
            </div>
        </div>
        <div class="col-md-6 no-gutters">
            <div class="rightside">
                <br>
                <br> <br>
                <h2 align="center">Listado de alumnos</h2>
                <br>
                <center>
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Nombre</th>
                                <th>Apellido</th>
                                <th>DNI</th>
                                <th></th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            while ($row = mysqli_fetch_array($query)) {
                                echo "<tr>";
                                echo "<td>$row[1]</td>";
                                echo "<td>$row[2]</td>";
                                echo "<td>$row[3]</td>";
                                echo "<td>
			                <form method='post' action='update_alumno.php'>
			                <input type='hidden' name='id' value='$row[0]'>
			                <input type='submit' value='EDITAR'>
			                </form>
			                </td>";
                                echo "<td>
			                <form method='post' action='delete_alumno.php'>
			                <input type='hidden' name='id' value='$row[0]'>
			                <input type='submit' value='ELIMINAR'>
			                </form>
			                </td>";
                                echo "</tr>";
                            }
                            mysqli_free_result($query);
                            mysqli_close($con);
                            ?>
                        </tbody>
                    </table>
                </center>
            </div>
        </div>
    </div>
</body>

</html>