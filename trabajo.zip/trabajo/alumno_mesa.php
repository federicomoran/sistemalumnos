<html>

<head>
    <title>Gestionando alumnos y mesas</title>
    <meta charset="utf-8">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="crud.css">
</head>

<body>
    <div class="row no-gutters">
        <div class="col-md-6 no-gutters">
            <div class="left">
                <p align="left"><a href="menu_tp.html">Volver</a></p>
                <h2 align="center"> Buscar alumnos </h2>
                <p align="center"><b>Ingrese el dni del alumno para consultar las mesas en las que se inscribió.</b></p>
                <br>
                <form method="POST" action="alumno_busqueda.php">
                    <center>
                        <table width="300" border="1">
                            <tr>
                                <td width="70"><b>DNI</b></td>
                                <td width="150"><input type="text" name="dni" value=""></td>
                            </tr>
                            <tr>
                                <td colspan="2" align="center"><input type="submit" value="Buscar"> </td>
                            </tr>
                        </table>
                    </center>
                </form>
                <center>
                    <table border="2">
                        <tr>
                            <thead>
                                <th>Nombre</th>
                                <th>Apellido</th>
                                <th>DNI</th>
                            </thead>
                        </tr>
                        <?php
                        include('conexion.php');
                        $con = conectar();
                        $alumno = "SELECT * FROM tbl_alumno";
                        $alumno_query = mysqli_query($con, $alumno);
                        while ($resultado = mysqli_fetch_row($alumno_query)) {

                            echo "<tr>";
                            echo "<td>$resultado[1]</td>";
                            echo "<td>$resultado[2]</td>";
                            echo "<td>$resultado[3]</td>";
                            echo "</tr>";
                        }

                        ?>
                    </table>
                </center>

            </div>
        </div>
        <div class="col-md-6 no-gutters">
            <div class="right">
                <br> <br>
                <h2 align="center">Buscar mesas</h2>

                <p align="center"><b>Seleccione alguna materia para ver los alumnos inscriptos.</b></p>
                <br>
                <?php

                $sql = "SELECT * FROM tbl_mesas";
                $query = mysqli_query($con, $sql);
                ?>
                <form method="POST" action="mesa_busqueda.php">
                    <center>
                        <table width="300" border="1">
                            <tr>
                                <td width="70"><b>Materia</b></td>
                                <td><select name="materia" required>
                                        <option value="0"></option>
                                        <?php while ($row = mysqli_fetch_row($query)) {
                                            echo '<option value="', $row[0], '">', $row[1], ', ', $row[5], '</option>';
                                        }  ?>
                                    </select></td>
                            </tr>
                            <tr>
                                <td colspan="2" align="center">
                                    <input type="submit" value="Buscar" align="center">
                                </td>
                            </tr>
                        </table>
                    </center>
                </form>
            </div>
        </div>
    </div>



</body>

</html>