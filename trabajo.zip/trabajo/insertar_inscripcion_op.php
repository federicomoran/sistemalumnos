<?php
require("conexion.php");
$con = conectar();

$form_al = $_POST["alumno"];
$form_me = $_POST["mesa"];
$form_con = $_POST["radio"];
date_default_timezone_set("America/Argentina/San_Juan");
$hoy = date("o,m,d");
$consulta = "SELECT * FROM tbl_inscripciones";
$resultado = mysqli_query($con, $consulta);
while ($row = mysqli_fetch_row($resultado)) {
    if (($form_al == $row[1]) && ($form_me == $row[3])) {
        echo "<script>
            alert('El alumno ya esta inscripto en esta mesa de examen');
            window.location= 'inscripcion_op.php';
            </script>";
        exit();
    }
}

$sql = "INSERT INTO tbl_inscripciones (alumno, fecha, mesa, tipo_mesa) VALUES ('$form_al','$hoy' ,'$form_me',  '$form_con')";
$query = mysqli_query($con, $sql);
mysqli_close($con);
echo "<script>
    alert('Su inscripcion fue realizada con éxito');
    window.location='inscripcion_op.php';
</script>";
