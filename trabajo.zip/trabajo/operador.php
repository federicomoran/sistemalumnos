<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Menu Operador</title>
    <link rel="stylesheet" href="estilos_tp.css">
</head>

<body>
    </center>
    <header class="header">
        <div class="container">
            <div class="btn-menu">
                <label for="btn-menu">☰</label>
            </div>
            <div class="logo">
                <h1>Menu Instituto</h1>
            </div>
            <nav class="menu">
                <a href=""></a>
                <a href="acceso_us.html">Salir</a>
            </nav>
        </div>
    </header>
    <div class="capa"></div>
    <!--	--------------->
    <input type="checkbox" id="btn-menu">
    <div class="container-menu">
        <div class="cont-menu">
            <nav>
                <a href="inscripcion_op.php">Inscripciones</a>
                <a href="listado_alumnos.php">Alumnos</a>
                <a href="listado_mesas.php">Mesas</a>
            </nav>
            <label for="btn-menu">✖️</label>
        </div>
    </div>

</body>

</html>