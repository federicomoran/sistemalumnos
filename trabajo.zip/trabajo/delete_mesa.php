<?php
include("conexion.php");
$con = conectar();

$form_id = $_POST["id"];
$sql = "DELETE FROM tbl_mesas WHERE id='$form_id'";
if (!mysqli_query($con, $sql)) {
    echo "<p>$sql</p>";
    exit();
}
echo "<script>
    alert('La mesa de examen fue eliminada');
    window.location='mesas.php';
</script>";
mysqli_close($con);
