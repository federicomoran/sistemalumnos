<html>

<head>
    <title>Update</title>
    <link rel="stylesheet" type="text/css" href="crud.css">
</head>

<body>
    <?php
    include("conexion.php");
    $con = conectar();
    $usuario = $_POST['id'];
    $sql = "SELECT * FROM tbl_usuario WHERE id='$usuario'";

    if (!($resultado = mysqli_query($con, $sql))) {
        echo "<p>$sql</p>";
        exit();
    }

    $row = mysqli_fetch_row($resultado);
    ?>
    <a href="usuarios.php">Volver</a>
    <form method="post" action="actualizar_usuario.php">
        <center>
            <table>
                <tr>
                    <td><input type="hidden" name="id" value="<?php echo $row[0] ?>"></td>
                </tr>
                <tr>
                    <td>Usuario</td>
                    <td><input type="text" name="usuario" value="<?php echo $row[1] ?>"></td>
                </tr>
                <tr>
                    <td>Contraseña</td>
                    <td><input type="text" name="password" value="<?php echo $row[2] ?>"></td>
                </tr>
                <tr>
                    <td>Nombre</td>
                    <td><input type="text" name="nombre" value="<?php echo $row[3] ?>"></td>
                </tr>
                <tr>
                    <td>Perfil</td>
                    <td><input type="text" name="perfil" value="<?php echo $row[4] ?>"></td>
                </tr>
                <tr>
                    <td></td>
                    <td><input type="submit" value="Actualizar"></td>
                </tr>
            </table>
        </center>
    </form>
    <?php
    mysqli_close($con);
    ?>
</body>

</html>