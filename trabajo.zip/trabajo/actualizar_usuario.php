<?php
include("conexion.php");
$con = conectar();

$id = $_POST["id"];
$usuario = $_POST["usuario"];
$clave = $_POST["password"];
$nombre = $_POST["nombre"];
$perfil = $_POST["perfil"];

$sql = "UPDATE tbl_usuario SET usuario='$usuario', clave='$clave', nombre='$nombre', tipo_us='$perfil' WHERE id='$id'";
if (!mysqli_query($con, $sql)) {
    echo "<p>$sql</p>";
    exit();
}
mysqli_close($con);
echo "<script>
alert('Se actualizo el usuario');
window.location='usuarios.php';
</script>";
