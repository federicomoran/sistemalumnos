<html>

<head>
    <title>Buscando alumno</title>
    <meta charset="utf-8">
    <link rel="stylesheet" type="text/css" href="crud.css">
</head>

<body>
    <?php
    include("conexion.php");
    $con = conectar();


    $form_dni = $_POST["dni"];
    $consulta = "SELECT * FROM tbl_alumno where dni='$form_dni'";


    if (!($resultado = mysqli_query($con, $consulta))) {
        exit();
    }


    if (mysqli_num_rows($resultado) == 0) {
        echo "<a href='alumno_mesa.php'>Volver</a>";
        echo "<h2>El dni ingresado ($form_dni), no corresponde a ningún alumno del Instituto. </h2>";
        exit();
    } else {
        $row_alumno = mysqli_fetch_row($resultado);
        $inscripcion = "SELECT * FROM tbl_inscripciones where alumno='$row_alumno[0]'";
        if (!($sql = mysqli_query($con, $inscripcion))) {
            exit();
        }
    }



    ?>
    <a href="alumno_mesa.php">Volver</a>
    <br> <br>
    <table border="1" width="90%">
        <p><b>El alumno se ha inscripto en las siguientes mesas con su respectiva nota.</b></p>
        <tr>
            <th>Apellido</th>
            <th>Nombre</th>
            <th>Mesa</th>
            <th>Fecha</th>
            <th>Asistencia</th>
            <th>Nota</th>
        </tr>
        <?php
        while ($row = mysqli_fetch_row($sql)) {
            echo "<tr>";
            echo "<td>$row_alumno[2]</td>";
            echo "<td>$row_alumno[1]</td>";
            $mesa = "SELECT * FROM tbl_mesas WHERE id='$row[3]'";
            $mesa_query = mysqli_query($con, $mesa);
            $row_mesa = mysqli_fetch_row($mesa_query);
            echo "<td>$row_mesa[1]</td>";
            echo "<td>$row_mesa[5]</td>";
            echo "<td>$row[5]</td>";
            echo "<td>$row[6]</td>";
            echo "</tr>";
        }
        mysqli_free_result($resultado);
        mysqli_close($con);
        ?>
    </table>
</body>

</html>