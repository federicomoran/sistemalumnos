<!DOCTYPE html>
<html>

<head>
	<title>Formulario de registro</title>
	<meta charset="utf-8">
</head>

<body>

	<?php
	include("conexion.php");
	$con = conectar();
	$form_us = $_POST['usuario'];
	$form_con = $_POST['password'];
	$form_no = $_POST['nombre'];
	$form_pe = $_POST['perfil'];

	$sql = "SELECT * FROM tbl_usuario";
	$query = mysqli_query($con, $sql);
	while ($row = mysqli_fetch_row($query)) {
		if ($form_us == $row[1]) {
			echo "<script>
            alert('Este usuario ya existe');
            window.location= 'registro.html';
            </script>";
			exit();
		}
	}

	$consulta = "INSERT INTO tbl_usuario(usuario, clave , nombre, tipo_us) VALUES ('$form_us', '$form_con', '$form_no', '$form_pe')";
	if (!($resultado = mysqli_query($con, $consulta))) {
		echo "<p>Error: La consulta SQL tiene problema, verificar.</p><br>";
		exit();
	}
	echo "<script>
			alert('Su registro se realizó con éxito');
			window.location='acceso_us.html';
			</script>";

	mysqli_close($con);
	?>
</body>

</html>