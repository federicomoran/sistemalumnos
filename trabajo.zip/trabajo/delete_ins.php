<?php
include("conexion.php");
$con = conectar();

$form_id = $_POST["id"];
$sql = "DELETE FROM tbl_inscripciones WHERE id='$form_id'";
if (!mysqli_query($con, $sql)) {
    echo "<p>$sql</p>";
    exit();
}
echo "<script>
    alert('La inscripcion fue eliminada');
    window.location='editar_ins.php';
</script>";
mysqli_close($con);
