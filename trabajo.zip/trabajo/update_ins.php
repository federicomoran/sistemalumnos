<html>

<head>
    <title>Update</title>
    <link rel="stylesheet" type="text/css" href="crud.css">
</head>

<body>
    <?php
    include("conexion.php");
    $con = conectar();
    $form_id = $_POST["id"];
    $sql = "SELECT * FROM tbl_inscripciones WHERE id='$form_id'";

    if (!($resultado = mysqli_query($con, $sql))) {
        echo "<p>$sql</p>";
        exit();
    }
    $row = mysqli_fetch_row($resultado);

    $sql_alum = "SELECT * FROM tbl_alumno WHERE id='$row[1]'";
    $query_alum = mysqli_query($con, $sql_alum);
    $row_alum = mysqli_fetch_row($query_alum);


    $sql_mesa = "SELECT * FROM tbl_mesas WHERE id='$row[3]'";
    $query_mesa = mysqli_query($con, $sql_mesa);
    $row_mesa = mysqli_fetch_row($query_mesa);

    ?>
    <a href="editar_ins.php">Volver</a>
    <form method="post" action="ins_editada.php">
        <center>
            <table>
                <tr>
                    <td><input type="hidden" name="id" value="<?php echo $row[0] ?>"></td>
                </tr>
                <tr>
                    <td>Alumno</td>
                    <td><input type="text" name="alumno" value="<?php echo $row_alum[2], ", ", $row_alum[1]   ?>" readonly></td>
                </tr>
                <tr>
                    <td>Fecha</td>
                    <td><input type="text" name="fecha" value="<?php echo $row[2] ?>" readonly></td>
                </tr>
                <tr>
                    <td>Mesa</td>
                    <td><input type="text" name="mesa" value="<?php echo $row_mesa[1] ?>" readonly></td>
                </tr>
                <tr>
                    <td>Condicion</td>
                    <td><input type="text" name="condicion" value="<?php echo $row[4] ?>" readonly></td>
                </tr>
                <tr>
                    <td>Asistencia</td>
                    <td><input type="text" name="asistencia" value="<?php echo $row[5] ?>"></td>
                </tr>
                <tr>
                    <td>Nota</td>
                    <td><input type="number" name="nota" value="<?php echo $row[6] ?>"></td>
                </tr>
                <tr>
                    <td></td>
                    <td><input type="submit" value="Actualizar"></td>
                </tr>
            </table>
        </center>

    </form>
    <?php
    mysqli_close($con);
    ?>
</body>

</html>