<html>

<head>
    <title>Listado de mesas habilitadas</title>
    <meta charset="utf-8">
    <link rel="stylesheet" type="text/css" href="tablas.css">
</head>

<body>
    <a href="menu_tp.html">Volver</a>
    <?php
    include('conexion.php');
    $con = conectar();

    date_default_timezone_set("America/Argentina/San_Juan");
    $hoy = date("o,m,d");


    $sql = "SELECT * FROM tbl_mesas WHERE fecha<'$hoy'";
    $query = mysqli_query($con, $sql);

    ?>
    <center>
        <div id="listado">
            <table class="lista">
                <thead>
                    <tr>
                        <th>Materia</th>
                        <th>Profesor</th>
                        <th>Suplente</th>
                        <th>Prof Vocal</th>
                        <th>Fecha</th>
                    </tr>
                </thead>
                <?php
                while ($row = mysqli_fetch_row($query)) {
                    echo "<tr>";
                    echo "<td><b>$row[1]</b></td>";
                    echo "<td>$row[2]</td>";
                    echo "<td>$row[3]</td>";
                    echo "<td>$row[4]</td>";
                    echo "<td>$row[5]</td>";
                    echo "</tr>";
                }
                ?>
            </table>
    </center>
    </div>
</body>

</html>