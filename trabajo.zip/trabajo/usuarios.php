<html>

<head>
    <title>Usuarios</title>
    <meta charset="utf-8">
    <link rel="stylesheet" type="text/css" href="tablas.css">
</head>

<body>
    <?php
    include('conexion.php');
    $con = conectar();
    $sql = "SELECT * FROM tbl_usuario";
    $query = mysqli_query($con, $sql);
    ?>
    <p align="left"><a href="menu_tp.html">Volver</a></p>
    <h2 align="center">Usuarios</h2>
    <br>
    <center>
        <div id="user">
            <table class="usuarios">
                <thead>
                    <tr>
                        <th>Usuario</th>
                        <th>Contraseña</th>
                        <th>Nombre</th>
                        <th>Perfil</th>
                        <th></th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    while ($row = mysqli_fetch_row($query)) {
                        echo "<tr>";
                        echo "<td>$row[1]</td>";
                        echo "<td>$row[2]</td>";
                        echo "<td>$row[3]</td>";
                        echo "<td>$row[4]</td>";
                        echo "<td>
            <form method='post' action='update_usuario.php'>
            <input type='hidden' name='id' value='$row[0]'>
            <input type='submit' value='EDITAR'>
            </form>
            </td>";
                        echo "<td>
            <form method='post' action='delete_usuario.php'>
            <input type='hidden' name='id' value='$row[0]'>
            <input type='submit' value='ELIMINAR'>
            </form>
            </td>";
                        echo "</tr>";
                    }
                    mysqli_free_result($query);
                    mysqli_close($con);
                    ?>
                </tbody>
            </table>
    </center>
    </div>
</body>

</html>