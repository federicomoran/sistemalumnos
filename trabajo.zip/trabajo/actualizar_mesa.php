<?php
include("conexion.php");
$con = conectar();

$form_id = $_POST["id"];
$form_nom = $_POST["nombre"];
$form_prof = $_POST["prof"];
$form_sup = $_POST["suplente"];
$form_voc = $_POST["vocal"];
$form_fe = $_POST["fecha"];

$sql = "UPDATE tbl_mesas SET materia='$form_nom', profesor='$form_prof', suplente='$form_sup', vocal='$form_voc', fecha='$form_fe' WHERE id='$form_id'";
if (!mysqli_query($con, $sql)) {
    echo "<p>$sql</p>";
    exit();
}
mysqli_close($con);
echo "<script>
alert('Se actualizó la mesa de examen');
window.location='mesas.php';
</script>";
