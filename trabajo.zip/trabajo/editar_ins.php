<html>

<head>
    <title>Editando Inscripciones</title>
    <meta charset="utf-8">
    <link rel="stylesheet" type="text/css" href="tablas.css">
</head>

<body>
    <?php
    include("conexion.php");
    $con = conectar();
    $sql = "SELECT * FROM tbl_inscripciones";
    if (!($query = mysqli_query($con, $sql))) {
        exit();
    }
    ?>
    <p align="left"><a href="menu_tp.html">Volver</a></p>
    <center>
        <div id="main-container">
            <table align="center">
                <thead>
                    <tr>
                        <th>Alumno</th>
                        <th>DNI</th>
                        <th>Fecha</th>
                        <th>Mesa</th>
                        <th>Condición</th>
                        <th>Asistencia</th>
                        <th>Nota</th>
                        <th></th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    while ($row = mysqli_fetch_row($query)) {
                        echo "<tr>";
                        $alumno = "SELECT * FROM tbl_alumno WHERE id='$row[1]'";
                        $consulta = mysqli_query($con, $alumno);
                        $columna = mysqli_fetch_row($consulta);
                        echo "<td>$columna[2], $columna[1]</td>";
                        echo "<td>$columna[3]</td>";
                        echo "<td>$row[2]</td>";
                        $sql_mesa = "SELECT * FROM tbl_mesas WHERE id='$row[3]'";
                        $query_mesa = mysqli_query($con, $sql_mesa);
                        $row_mesa = mysqli_fetch_row($query_mesa);
                        echo "<td>$row_mesa[1]</td>";
                        echo "<td>$row[4]</td>";
                        echo "<td>$row[5]</td>";
                        echo "<td>$row[6]</td>";
                        echo "<td>
		<form method='post' action='update_ins.php'>
		<input type='hidden' name='id' value='$row[0]'>
		<input type='submit' value='EDITAR'>
		</form>
		</td>";
                        echo "<td>
		<form method='post' action='delete_ins.php'>
	    <input type='hidden' name='id' value='$row[0]'>
	    <input type='submit' value='ELIMINAR'>
		</form>
		</td>";
                        echo "</tr>";
                    }
                    mysqli_free_result($query);
                    mysqli_close($con);
                    ?>
                </tbody>
            </table>
        </div>
    </center>
</body>

</html>