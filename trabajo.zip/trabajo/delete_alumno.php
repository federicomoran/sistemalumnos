<?php
include("conexion.php");
$con = conectar();
$form_id = $_POST["id"];

$consulta = "SELECT * FROM tbl_inscripciones";
$query = mysqli_query($con, $consulta);
while ($row = mysqli_fetch_row($query)) {
    if ($row[1] == $form_id) {
        echo "<script>alert('Para eliminar este alumno, elimine primero su inscripcion generada');
        window.location='alumno.php';
        </script>";
        exit();
    }
}

$sql = "DELETE FROM tbl_alumno WHERE id='$form_id'";
if (!mysqli_query($con, $sql)) {
    echo "<p>$sql</p>";
    exit();
}
mysqli_close($con);
echo "<script>
    alert('El alumno fue eliminado');
    window.location='alumno.php';
</script>";
