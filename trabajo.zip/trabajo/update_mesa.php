<html>

<head>
    <title>Update</title>
    <link rel="stylesheet" type="text/css" href="crud.css">
</head>

<body>
    <?php
    include("conexion.php");
    $con = conectar();
    $form_id = $_POST["id"];
    $sql = "SELECT * FROM tbl_mesas WHERE id='$form_id'";

    if (!($resultado = mysqli_query($con, $sql))) {
        echo "<p>$sql</p>";
        exit();
    }

    $row = mysqli_fetch_row($resultado);
    ?>
    <a href="mesas.php">Volver</a>
    <form method="post" action="actualizar_mesa.php">
        <center>
            <table>
                <tr>
                    <td><input type="hidden" name="id" value="<?php echo $row[0] ?>"></td>
                </tr>
                <tr>
                    <td>Materia</td>
                    <td><input type="text" name="nombre" value="<?php echo $row[1] ?>"></td>
                </tr>
                <tr>
                    <td>Profesor</td>
                    <td><input type="text" name="prof" value="<?php echo $row[2] ?>"></td>
                </tr>
                <tr>
                    <td>Profesor suplente</td>
                    <td><input type="text" name="suplente" value="<?php echo $row[3] ?>"></td>
                </tr>
                <tr>
                    <td>Profesor vocal suplente</td>
                    <td><input type="text" name="vocal" value="<?php echo $row[4] ?>"></td>
                </tr>
                <tr>
                    <td>Fecha</td>
                    <td><input type="text" name="fecha" value="<?php echo $row[5] ?>"></td>
                </tr>
                <tr>
                    <td></td>
                    <td><input type="submit" value="Actualizar"></td>
                </tr>
            </table>
        </center>
    </form>
    <?php
    mysqli_close($con);
    ?>
</body>

</html>