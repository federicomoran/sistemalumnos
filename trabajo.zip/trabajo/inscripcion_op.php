<html>

<head>
    <title>Inscripciones</title>
    <meta charset="utf-8">
    <link rel="stylesheet" type="text/css" href="crud.css">
</head>

<body>
    <?php
    require("conexion.php");
    $con = conectar();
    $consulta = "SELECT * FROM tbl_alumno";
    $query_alum = mysqli_query($con, $consulta);


    date_default_timezone_set("America/Argentina/San_Juan");
    $hoy = date("o,m,d");


    $sql_mesa = "SELECT * FROM tbl_mesas WHERE fecha>='$hoy'";
    $query_mesa = mysqli_query($con, $sql_mesa);
    ?>
    <center>
        <p align="left"><a href="operador.php">Volver</a></p>
        <form method="POST" action="insertar_inscripcion_op.php">
            <table class="listado">
                <tr>
                    <th>Seleccione alumno</th>
                    <td><select name="alumno" required>
                            <option value="0"></option>
                            <?php while ($row = mysqli_fetch_array($query_alum)) {
                                echo '<option value="', $row[0], '">', $row[2], ', ', $row[1], '</option>';
                            }  ?>
                        </select></td>
                </tr>
                <tr>
                    <th>Seleccione mesa</th>
                    <td><select name="mesa" required>
                            <option value="0"></option>
                            <?php while ($row_mesa = mysqli_fetch_row($query_mesa)) {
                                echo '<option value="', $row_mesa[0], '">', $row_mesa[1], ' </option>';
                            } ?>
                        </select></td>
                </tr>
                <tr>
                    <th>Condicion</th>
                    <td><input type="radio" name="radio" value="Regular">Regular<input type="radio" name="radio" value="Libre">Libre</td>
                </tr>
                <tr>
                    <td></td>
                    <td><input type="submit" value="Enviar"></td>
                </tr>

            </table>
        </form>

    </center>
    <?php
    echo "<br> <br> ";
    echo "<center><a href='listado_alumnos.php'>Ir a listado de alumnos</a>";
    echo "<br> <br> <br>";
    echo "<a href='listado_mesas.php'>Ir a listado de mesas</a></center>";
    ?>
    <br> <br> <br> <br>
    <br> <br> <br> <br>
    <br> <br> <br> <br>
    <br> <br>
    <?php
    $user = "SELECT * FROM tbl_usuario WHERE tipo_us='operador'";
    $result_us = mysqli_query($con, $user);
    $usuario = mysqli_fetch_row($result_us);
    echo "<p align='right'> Perfil: <b>$usuario[3]</b></p> "; ?>
</body>

</html>