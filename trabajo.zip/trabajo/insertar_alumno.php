<?php
include("conexion.php");
$con = conectar();

$form_nom = $_POST["nombre"];
$form_ap = $_POST["apellido"];
$form_dni = $_POST["dni"];

$consulta = "SELECT * FROM tbl_alumno";
$resultado = mysqli_query($con, $consulta);
while ($row = mysqli_fetch_row($resultado)) {
    if ($form_dni == $row[3]) {
        echo "<script>
            alert('El alumno ya esta registrado');
            window.location= 'alumno.php';
            </script>";
        exit();
    }
}

$sql = "INSERT INTO tbl_alumno (nombre, apellido, dni) VALUES('$form_nom', '$form_ap', '$form_dni')";
$query = mysqli_query($con, $sql);

mysqli_close($con);
echo "<script>
    alert('Su registro fue ingresado con éxito');
    window.location='alumno.php';
</script>";
